﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hello! World.");
            Console.WriteLine("歡迎光臨 C# 的世界.");
          Console.Read();
        }
    }
}
