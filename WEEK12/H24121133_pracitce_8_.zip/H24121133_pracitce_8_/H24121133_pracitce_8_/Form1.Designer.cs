﻿namespace H24121133_pracitce_8_
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.bindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet22 = new H24121133_pracitce_8_.Database1DataSet2();
            this.bindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.寶可夢_招式TableAdapter2 = new H24121133_pracitce_8_.Database1DataSet2TableAdapters.寶可夢_招式TableAdapter();
            this.寶可夢DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.bindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.招式_屬性_威力TableAdapter2 = new H24121133_pracitce_8_.Database1DataSet2TableAdapters.招式_屬性_威力TableAdapter();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.威力DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.bindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.屬性_克制屬性_被克制屬性TableAdapter1 = new H24121133_pracitce_8_.Database1DataSet2TableAdapters.屬性_克制屬性_被克制屬性TableAdapter();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource5)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.寶可夢DataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn1});
            this.dataGridView4.DataSource = this.bindingSource3;
            this.dataGridView4.Location = new System.Drawing.Point(12, 12);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.RowTemplate.Height = 27;
            this.dataGridView4.Size = new System.Drawing.Size(430, 175);
            this.dataGridView4.TabIndex = 0;
            // 
            // database1DataSet22
            // 
            this.database1DataSet22.DataSetName = "Database1DataSet2";
            this.database1DataSet22.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingSource3
            // 
            this.bindingSource3.DataMember = "寶可夢_招式";
            this.bindingSource3.DataSource = this.database1DataSet22;
            // 
            // 寶可夢_招式TableAdapter2
            // 
            this.寶可夢_招式TableAdapter2.ClearBeforeFill = true;
            // 
            // 寶可夢DataGridViewTextBoxColumn
            // 
            this.寶可夢DataGridViewTextBoxColumn.DataPropertyName = "寶可夢";
            this.寶可夢DataGridViewTextBoxColumn.HeaderText = "寶可夢";
            this.寶可夢DataGridViewTextBoxColumn.MinimumWidth = 6;
            this.寶可夢DataGridViewTextBoxColumn.Name = "寶可夢DataGridViewTextBoxColumn";
            this.寶可夢DataGridViewTextBoxColumn.Width = 125;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "招式";
            this.dataGridViewTextBoxColumn1.HeaderText = "招式";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridView5
            // 
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.威力DataGridViewTextBoxColumn});
            this.dataGridView5.DataSource = this.bindingSource4;
            this.dataGridView5.Location = new System.Drawing.Point(12, 193);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 51;
            this.dataGridView5.RowTemplate.Height = 27;
            this.dataGridView5.Size = new System.Drawing.Size(430, 150);
            this.dataGridView5.TabIndex = 1;
            // 
            // bindingSource4
            // 
            this.bindingSource4.DataMember = "寶可夢_招式_招式_屬性_威力";
            this.bindingSource4.DataSource = this.bindingSource3;
            // 
            // 招式_屬性_威力TableAdapter2
            // 
            this.招式_屬性_威力TableAdapter2.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "招式";
            this.dataGridViewTextBoxColumn2.HeaderText = "招式";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "屬性";
            this.dataGridViewTextBoxColumn3.HeaderText = "屬性";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // 威力DataGridViewTextBoxColumn
            // 
            this.威力DataGridViewTextBoxColumn.DataPropertyName = "威力";
            this.威力DataGridViewTextBoxColumn.HeaderText = "威力";
            this.威力DataGridViewTextBoxColumn.MinimumWidth = 6;
            this.威力DataGridViewTextBoxColumn.Name = "威力DataGridViewTextBoxColumn";
            this.威力DataGridViewTextBoxColumn.Width = 125;
            // 
            // dataGridView6
            // 
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.dataGridView6.DataSource = this.bindingSource5;
            this.dataGridView6.Location = new System.Drawing.Point(12, 349);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowHeadersWidth = 51;
            this.dataGridView6.RowTemplate.Height = 27;
            this.dataGridView6.Size = new System.Drawing.Size(430, 150);
            this.dataGridView6.TabIndex = 2;
            // 
            // bindingSource5
            // 
            this.bindingSource5.DataMember = "招式_屬性_威力_屬性_克制屬性_被克制屬性";
            this.bindingSource5.DataSource = this.bindingSource4;
            // 
            // 屬性_克制屬性_被克制屬性TableAdapter1
            // 
            this.屬性_克制屬性_被克制屬性TableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "屬性";
            this.dataGridViewTextBoxColumn4.HeaderText = "屬性";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "克制屬性";
            this.dataGridViewTextBoxColumn5.HeaderText = "克制屬性";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "被克制屬性";
            this.dataGridViewTextBoxColumn6.HeaderText = "被克制屬性";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(766, 529);
            this.Controls.Add(this.dataGridView6);
            this.Controls.Add(this.dataGridView5);
            this.Controls.Add(this.dataGridView4);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource 招式屬性威力BindingSource;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource database1DataSet2BindingSource;
        private Database1DataSet2 database1DataSet2;
        private System.Windows.Forms.BindingSource 招式屬性威力BindingSource1;
        private Database1DataSet2TableAdapters.招式_屬性_威力TableAdapter 招式_屬性_威力TableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn 招式DataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource 寶可夢招式BindingSource;
        private Database1DataSet2TableAdapters.寶可夢_招式TableAdapter 寶可夢_招式TableAdapter;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingSource 寶可夢招式BindingSource1;
        private System.Windows.Forms.BindingSource 招式屬性威力屬性克制屬性被克制屬性BindingSource;
        private Database1DataSet2TableAdapters.屬性_克制屬性_被克制屬性TableAdapter 屬性_克制屬性_被克制屬性TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn 屬性DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 克制屬性DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 被克制屬性DataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource 寶可夢招式BindingSource2;
        private System.Windows.Forms.BindingSource 寶可夢招式BindingSource3;
        private System.Windows.Forms.DataGridViewTextBoxColumn 寶可夢;
        private System.Windows.Forms.DataGridViewTextBoxColumn 招式DataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource 屬性克制屬性被克制屬性BindingSource;
        private System.Windows.Forms.BindingSource 招式屬性威力BindingSource2;
        private System.Windows.Forms.BindingSource 寶可夢招式招式屬性威力BindingSource;
        private System.Windows.Forms.BindingSource 招式屬性威力屬性克制屬性被克制屬性BindingSource1;
        private System.Windows.Forms.BindingSource 寶可夢招式招式屬性威力BindingSource1;
        private Database1DataSet2 database1DataSet21;
        private System.Windows.Forms.BindingSource 寶可夢招式BindingSource4;
        private System.Windows.Forms.BindingSource 寶可夢招式招式屬性威力BindingSource2;
        private System.Windows.Forms.BindingSource 寶可夢招式BindingSource5;
        private System.Windows.Forms.BindingSource 寶可夢招式招式屬性威力BindingSource3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.BindingSource bindingSource2;
        private Database1DataSet2 database1DataSet22;
        private System.Windows.Forms.BindingSource bindingSource3;
        private Database1DataSet2TableAdapters.寶可夢_招式TableAdapter 寶可夢_招式TableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn 寶可夢DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.BindingSource bindingSource4;
        private Database1DataSet2TableAdapters.招式_屬性_威力TableAdapter 招式_屬性_威力TableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn 威力DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.BindingSource bindingSource5;
        private Database1DataSet2TableAdapters.屬性_克制屬性_被克制屬性TableAdapter 屬性_克制屬性_被克制屬性TableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}

