using System.Media;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using static System.Windows.Forms.DomainUpDown;
using WMPLib;
using System.Xml.Linq;

namespace H24121133_practice_6_2
{
    public partial class Form1 : Form
    {
        string typee = "";
        WMPLib.WindowsMediaPlayer wplayer = new WMPLib.WindowsMediaPlayer();
        SoundPlayer sp = new SoundPlayer();
        string sfilename;
        bool alarm_flag = false;
        bool flagg = false;
        bool flag = false;
        string MA = "", FM = "-1", FH = "-1";
        string alala = "";
        string ma = "";
        string alarm_h = "";
        string alarm_m = "";
        string cur_time;
        string hh, mm, ss;
        int h, m, s;
        PictureBox[,] pb = new PictureBox[6, 35];

        private void timer1_Tick(object sender, EventArgs e)
        {
            clearcolor();
            hh = DateTime.Now.ToString("HH");
            mm = DateTime.Now.ToString("mm");
            ss = DateTime.Now.ToString("ss");
            h = int.Parse(hh);
            m = int.Parse(mm);
            s = int.Parse(ss);
            if (h >= 12)
            {
                h = h - 12;
                label3.Text = "�U��";
            }
            else
            {
                label3.Text = "�W��";
            }
            if (alarm_flag)
            {
                if (typee == ".mp3")
                {
                    wplayer.controls.play();
                }
                else
                {
                    sp.Play();
                }
            }
            if (int.Parse(FH) == h && int.Parse(FM) == m && MA == label3.Text)
            {
                alarm_flag = true;
                if (typee == ".mp3")
                {
                    wplayer.controls.play();
                }
                else
                {
                    sp.Play();
                }
                MA = "";
                string cc = "";
                if (label3.Text == "�U��") cc = DateTime.Now.ToString("yyyy/MM/dd �U�� hh:mm:ss: �x���T�a");
                else cc = DateTime.Now.ToString("yyyy/MM/dd �W�� hh:mm:ss: �x���T�a");
                textBox1.Text += cc + "\n";
                MessageBox.Show("�ɶ���! �Ӱ_���o~");
            }
            //label3.Text = hh + " " + mm + " " + ss;
            setNum(0, h / 10);
            setNum(1, h % 10);
            setNum(2, m / 10);
            setNum(3, m % 10);
            setNum(4, s / 10);
            setNum(5, s % 10);
            //label3.Text = cur_time.Substring(0, 2);
        }
        private void XD()
        {
        }
        private void clearcolor()
        {
            for(int i = 0; i < 6; i++)
            {
                for(int j = 0; j < 35; j++)
                {
                    pb[i, j].BackColor = Color.White;
                }
            }
        }
        public Form1()
        {
            ssss();
            for(int i = 0; i < 6; i++)
            {
                for(int j = 0; j < 35; j++)
                {
                    pb[i, j] = new PictureBox();
                    pb[i, j].Width = 30;
                    pb[i, j].Height = 30;
                    pb[i, j].Visible = true;
                    pb[i, j].BorderStyle = BorderStyle.FixedSingle;
                    pb[i, j].BringToFront();
                    pb[i, j].Size = new Size(30, 30);
                    pb[i, j].BackColor = System.Drawing.Color.White;
                    pb[i, j].Location = new Point(20 + (j % 5) * 30 + i * 180,20 + (j / 5) * 30);
                    this.Controls.Add(pb[i, j]);
                }
            }
            label3 = new Label();
            label3.Text = "";
            label3.Size = new Size(70, 30);
            label3.Location = new Point(50 + ((34 % 5) * 30) + (7 * 180),20 + ((34 / 5) * 30));
            InitializeComponent();
            timer1.Interval= 1000;
            timer1.Start();
        }
        private void ssss()
        {
            domainUpDown1 = new DomainUpDown();
            domainUpDown1.ReadOnly = true;
            domainUpDown1.Size = new Size(150, 27);
            domainUpDown1.Location = new Point(982, 406);
            domainUpDown1.SelectedItemChanged += domainUpDown1_SelectedItemChanged;
            this.Controls.Add(domainUpDown1);
            List<string> list1 = new List<string> {"�W��","�U��" };
            List<string> list2 = new List<string>();
            List<string> list3 = new List<string>();
            for(int i = 0; i <= 12; i++)
            {
                if(i < 10)
                {
                    list2.Add("0" + i.ToString());
                }
                else
                {
                    list2.Add(i.ToString());
                }
            }
            for(int i = 0; i < 60; i++)
            {
                if (i < 10)
                {
                    list3.Add("0" + i.ToString());
                }
                else
                {
                    list3.Add(i.ToString());
                }
            }
            string s = "";
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 13; j++)
                {
                    if(i == 1 && j == 12)
                    {
                        s = list1[i] + " 00:00";
                        this.domainUpDown1.Items.Add(s);
                        continue;
                    }
                    for(int k = 0; k < 60; k++)
                    {
                        s = list1[i] + " " + list2[j] + ":" + list3[k];
                        this.domainUpDown1.Items.Add(s);
                    }
                }
            }
            //this.domainUpDown1.Text = this.domainUpDown1.Items.Count.ToString();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string cc;
            if (!flag)
            {
                if (alala == "")
                {
                    MessageBox.Show("����J�x���ɶ�");
                    if (label3.Text == "�U��") cc = DateTime.Now.ToString("yyyy/MM/dd �U�� hh:mm:ss: ���~�T��!");
                    else cc = DateTime.Now.ToString("yyyy/MM/dd �W�� hh:mm:ss: ���~�T��!");
                    textBox1.Text += cc + "\n";
                }
                else if (!flagg)
                {
                    MessageBox.Show("�Х���ܾx�a!");
                    if (label3.Text == "�U��") cc = DateTime.Now.ToString("yyyy/MM/dd �U�� hh:mm:ss: ���~�T��!");
                    else cc = DateTime.Now.ToString("yyyy/MM/dd �W�� hh:mm:ss: ���~�T��!");
                    textBox1.Text += cc + "\n";
                }
                else
                {
                    if (label3.Text == "�U��") cc = DateTime.Now.ToString("yyyy/MM/dd �U�� hh:mm:ss: �w�]�w�x��");
                    else cc = DateTime.Now.ToString("yyyy/MM/dd �W�� hh:mm:ss: �w�]�w�x��");
                    MA = ma;
                    FH = alarm_h;
                    FM = alarm_m;
                    MessageBox.Show(MA + " " + FH + " " + FM);
                    textBox1.Text += cc + "\n";
                    flag = true;
                    button2.Text = "����";
                }
            }
            else
            {
                flag = false;
                if (label3.Text == "�U��") cc = DateTime.Now.ToString("yyyy/MM/dd �U�� hh:mm:ss: �w�����x��");
                else cc = DateTime.Now.ToString("yyyy/MM/dd �W�� hh:mm:ss: �w�����x��");
                textBox1.Text += cc + "\n";
                button2.Text = "�Ұ�";
                FM = "-1";
                FH = "-1";
                alarm_flag = false;
                if (typee == ".mp3")
                {
                    wplayer.controls.stop();
                }
                else
                {
                    sp.Stop();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "|*.wav;*mp3";
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                sfilename = ofd.FileName;
                sp.SoundLocation = sfilename;
                wplayer.URL = sfilename;
                flagg = true;
                label4.Text = ofd.FileName;
                typee = System.IO.Path.GetExtension(sfilename);
            }
            else
            {
                flagg = false;
                label4.Text = "�|����ܾx�a";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.DefaultExt = "txt";
            sfd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using(StreamWriter sw = new StreamWriter(sfd.FileName))
                {
                    sw.WriteLine(textBox1.Text);
                }
            }
            string cc = "";
            if (label3.Text == "�U��") cc = DateTime.Now.ToString("yyyy/MM/dd �U�� hh:mm:ss: �w�ץX�O����");
            else cc = DateTime.Now.ToString("yyyy/MM/dd �W�� hh:mm:ss: �w�ץX�O����");
            textBox1.Text += cc + "\n";

        }
        private void button2_Click(object sender, EventArgs e)
        {
            //domainUpDown1.Text = (domainUpDown1.Items.Count + 1).ToString();
        }

        private void domainUpDown1_Click(object sender, EventArgs e)
        {
        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {

            DomainUpDown dup = (DomainUpDown)sender;
            alala = dup.Text;
            ma = dup.Text.Substring(0, 2);
            alarm_h = dup.Text.Substring(3, 2);
            alarm_m = dup.Text.Substring(6, 2);
            //MessageBox.Show(dup.Text);
            //Text = this.domainUpDown1.Text;
            //domainUpDown1.Text = (domainUpDown1.Items.Count + 1).ToString();
        }

        private void color(int pos,List<int> t)
        {
            for(int i = 0; i < t.Count; i++)
            {
                pb[pos,t[i]].BackColor = System.Drawing.Color.Blue;
            }
        }
        private void setNum(int pos,int num)
        {
            List<int> t = new List<int>();
            if(num == 0)
            {
                 t = new List<int> { 1,2,3,5,9,10,14,20,24,25,29,31,32,33};
            }
            else if(num == 1)
            {
                t = new List<int> { 9,14,24,29};
            }
            else if(num == 2)
            {
                t = new List<int> { 1,2,3,9,14,16,17,18,20,25,31,32,33};
            }
            else if(num == 3)
            {
                t = new List<int> { 1,2,3,9,14,16,17,18,24,29,31,32,33};
            }
            else if(num == 4)
            {
                t = new List<int> { 5,9,10,14,16,17,18,24,29};
            }
            else if(num == 5)
            {
                t = new List<int> { 1,2,3,5,10,16,17,18,24,29,31,32,33};
            }
            else if(num == 6)
            {
                t = new List<int> { 1,2,3,5,10,16,17,18,20,24,25,29,31,32,33};
            }
            else if(num == 7)
            {
                t = new List<int> { 1,2,3,9,14,24,29};
            }
            else if(num == 8)
            {
                t = new List<int> { 1,2,3,5,9,10,14,16,17,18,20,24,25,29,31,32,33};
            }
            else if(num == 9)
            {
                t = new List<int> { 1,2,3,5,9,10,14,16,17,18,24,29,31,32,33};
            }
            color(pos, t);
        }
    }
}