using System.Numerics;
using System.Windows.Forms;

namespace H24121133_practice_6_1
{
    public partial class Form1 : Form
    {
        List<Button> button_array = new List<Button>();
        List<int> ans = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        int cnt = 0;
        string path;
        int time_minute, time_second;
        bool start_flag;
        int now_block,prev_block;
        bool game_start_ing;
        public Form1()
        {
            InitializeComponent();
            for(int i = 1; i <= 9; i++)
            {
                button_array.Add((Button)this.Controls["button" + (i).ToString()]);
            }
            for(int i = 0; i < 3; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    button_array[i * 3 + j].Visible = true;
                    button_array[i * 3 + j].Size = new Size(90, 90);
                    button_array[i * 3 + j].Location = new Point(20 + j * 100, 20 + i * 100);
                    button_array[i * 3 + j].Click += new System.EventHandler(buttonImage_Click);
                }
            }
            button_array[8].Visible = false;
            pictureBox1.Visible = true;
            pictureBox1.Size = new Size(280, 270);
            pictureBox1.Location = new Point(500, 20);
            Select_Image_Button.Visible = true;
            Select_Image_Button.Size = new Size(200, 35);
            Select_Image_Button.Location = new Point(550, 370);
            Select_Image_Button.Click += new System.EventHandler(Select_Image_Button_Click);
            Select_Image_Button.Text = "��ܹϤ�";
            Divide_Image_Button.Visible = true;
            Divide_Image_Button.Size = new Size(200, 35);
            Divide_Image_Button.Location = new Point(70, 370);
            Divide_Image_Button.Click += new System.EventHandler(Divide_Image_Button_Click);
            Divide_Image_Button.Text = "ø�s���ϪO";
            label1.Visible = true;
            label1.Location = new Point(335, 70);
            label1.Size = new Size(100, 20);
            label1.Text = "Time:";
            label2.Visible = true;
            label2.Location = new Point(335, 100);
            label2.Size = new Size(100, 20);
            label2.Text = "���ʨB��:";
            start_flag = false;
            trackBar2.Visible = true;
            trackBar2.Location = new Point(550, 325);
            trackBar2.Size = new Size(200, 30);
            trackBar2.Maximum = 1;
            label3.Text = "�����";
            label3.Location = new Point(493, 334);
            label4.Text = "���";
            label4.Location = new Point(756, 334);
            stop_move();
        }

        private void Select_Image_Button_Click(object sender, EventArgs e)
        {
            OpenFileDialog Dialog = new OpenFileDialog();
            if(Dialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = Dialog.FileName.ToString();
                /*path = Path.Combine(@"~\image");
                if(!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                var filename = System.IO.Path.GetFileName(Dialog.FileName);
                path = path + filename;*/
                start_flag = true;
            }
            pictureBox1.Size = new System.Drawing.Size(270, 270);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        private Image ZoomPicture(Image pic)
        {
            Bitmap source = new Bitmap(pic,270, 270);
            return source;
        }
        private void Divide_Image_Button_Click(object sender, EventArgs e)
        {
            if (!start_flag)
            {
                MessageBox.Show("�Х���ܹϤ�", "����", MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }

            pictureBox1.Image = ZoomPicture(pictureBox1.Image);
            Bitmap sourceImage = new Bitmap(pictureBox1.Image,270,270);
            int picWidth = 90;
            int picHeight = 90;
            int cnt = 0;
            for (int idxY = 0; idxY < 3; idxY++)
            {
                for (int idxX = 0; idxX < 3; idxX++)
                {
                    Bitmap pic = new Bitmap(picWidth, picHeight);
                    Graphics graphic = Graphics.FromImage(pic);
                    graphic.DrawImage(sourceImage,
                             new Rectangle(0, 0, picWidth, picHeight),
                             new Rectangle(picWidth * idxX, picHeight * idxY, picWidth, picHeight),
                             GraphicsUnit.Pixel);
                    button_array[cnt].Image = pic;
                    button_array[cnt++].BackgroundImageLayout = ImageLayout.Stretch;
                }
            }
            for (int i = 0; i < 9; i++)
            {
                button_array[i].Enabled = true;
                button_array[i].Visible = true;
            }
            start_move();
        }
        private void swap_image(int left,int right)
        {
            if (button_array[right].Visible == button_array[left].Visible) return;
            if(!button_array[right].Visible)
            {
                button_array[left].Visible = false;
                button_array[right].Visible = true;
            }
            if(!button_array[left].Visible)
            {
                button_array[right].Visible = false;
                button_array[left].Visible = true;
            }
            int tmp = ans[left];
            ans[left] = ans[right];
            ans[right] = tmp;
            Image tmp2 = button_array[left].Image;
            button_array[left].Image = button_array[right].Image;
            button_array[right].Image = tmp2;
        }
        List<int> dx = new List<int> { 3, -3, 1, -1 };
        private void conditon(int n)
        {
            for(int i = 0; i < 4; i++)
            {
                int dn = n + dx[i];
                if (dn < 0 || dn >= 9) continue;
                if (!button_array[dn].Visible)
                {
                    swap_image(dn, n);
                    label2.Text = "���ʨB��: " + cnt.ToString();
                    cnt++;
                    break;
                }
            }
            if (win_check())
            {
                timer1.Stop();
                stop_move();
                MessageBox.Show("�A��ӤF!\n�����ɶ�: " + label1.Text.Substring(5) + "\n���ʨB��: " + (cnt - 1).ToString());
            }
        }
        private void Rnd_Image()
        {
            List<int> now_can_move = new List<int>();
            for(int i = 0; i < 4; i++)
            {
                int dn = dx[i] + now_block;
                if (dn >= 9 || dn < 0 || dn == prev_block) continue;
                now_can_move.Add(dn);
            }
            Random random = new Random();
            prev_block = now_block;
            now_block = now_can_move[random.Next(0,now_can_move.Count())];
            swap_image(prev_block,now_block);
        }
        private void start_move()
        {
            game_start_ing = true;
            now_block = 8;
            prev_block = 8;
            for (int i = 0; i < 9; i++)
            {
                button_array[i].Enabled = true;
            }
            button_array[8].Visible = false;
            for (int i = 0; i < 100; i++)
            {
                Rnd_Image();
            }
            cnt = 1;
            time_second = 0;
            time_minute = 0;
            //timer1.Tick += new EventHandler(timer1_Tick);
            timer1.Interval = 1000;
            timer1.Start();

        }
        private void stop_move()
        {
            for(int i = 0; i < 9; i++)
            {
                button_array[i].Enabled = false;
            }
        }
        private void buttonImage_Click(object sender, EventArgs e)
        { 
            Button ne = (Button)sender;
            conditon(ne.Name[6] - '1');
        }
        private bool win_check()
        {
            for(int i = 0; i < 9; i++)
            {
                if (ans[i] != (i + 1)) return false;
            }
            return true;
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            if(trackBar2.Value == 1)
            {
                pictureBox1.Visible = true;
            }
            else
            {
                pictureBox1.Visible = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time_second++;
            if(time_second == 60)
            {
                time_second = 0;
                time_minute++;
            }
            if(time_minute < 10)
            {
                if(time_second < 10)
                {
                    label1.Text = "Time: 0" + time_minute.ToString() + ":0" + time_second.ToString();
                }
                else
                {
                    label1.Text = "Time: 0" + time_minute.ToString() + ":" + time_second.ToString();
                }
            }
            else
            {
                if(time_second < 10)
                {
                    label1.Text = "Time: " + time_minute.ToString() + ":0" + time_second.ToString();
                }
                else
                {
                    label1.Text = "Time: " + time_minute.ToString() + ":" + time_second.ToString();
                }
            }
        }
    }
}