﻿namespace H24121133_practice_4_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tool = new System.Windows.Forms.GroupBox();
            this.rb4 = new System.Windows.Forms.RadioButton();
            this.rb3 = new System.Windows.Forms.RadioButton();
            this.rb2 = new System.Windows.Forms.RadioButton();
            this.rb1 = new System.Windows.Forms.RadioButton();
            this.B12 = new System.Windows.Forms.Button();
            this.B11 = new System.Windows.Forms.Button();
            this.B10 = new System.Windows.Forms.Button();
            this.B9 = new System.Windows.Forms.Button();
            this.B8 = new System.Windows.Forms.Button();
            this.B7 = new System.Windows.Forms.Button();
            this.B6 = new System.Windows.Forms.Button();
            this.B5 = new System.Windows.Forms.Button();
            this.B4 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.money_label = new System.Windows.Forms.Label();
            this.buy_sell = new System.Windows.Forms.Button();
            this.fruit_label = new System.Windows.Forms.Label();
            this.fert_label = new System.Windows.Forms.Label();
            this.seed_label = new System.Windows.Forms.Label();
            this.fruit = new System.Windows.Forms.CheckBox();
            this.fert = new System.Windows.Forms.CheckBox();
            this.seed = new System.Windows.Forms.CheckBox();
            this.pic = new System.Windows.Forms.ImageList(this.components);
            this.TabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tool.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.tabPage1);
            this.TabControl1.Controls.Add(this.tabPage2);
            this.TabControl1.Location = new System.Drawing.Point(0, 0);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(788, 461);
            this.TabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tool);
            this.tabPage1.Controls.Add(this.B12);
            this.tabPage1.Controls.Add(this.B11);
            this.tabPage1.Controls.Add(this.B10);
            this.tabPage1.Controls.Add(this.B9);
            this.tabPage1.Controls.Add(this.B8);
            this.tabPage1.Controls.Add(this.B7);
            this.tabPage1.Controls.Add(this.B6);
            this.tabPage1.Controls.Add(this.B5);
            this.tabPage1.Controls.Add(this.B4);
            this.tabPage1.Controls.Add(this.B3);
            this.tabPage1.Controls.Add(this.B2);
            this.tabPage1.Controls.Add(this.B1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(780, 429);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "農場";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tool
            // 
            this.tool.Controls.Add(this.rb4);
            this.tool.Controls.Add(this.rb3);
            this.tool.Controls.Add(this.rb2);
            this.tool.Controls.Add(this.rb1);
            this.tool.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tool.Location = new System.Drawing.Point(377, 301);
            this.tool.Name = "tool";
            this.tool.Size = new System.Drawing.Size(400, 125);
            this.tool.TabIndex = 14;
            this.tool.TabStop = false;
            this.tool.Text = "工具";
            this.tool.Enter += new System.EventHandler(this.tool_Enter);
            // 
            // rb4
            // 
            this.rb4.AutoSize = true;
            this.rb4.Location = new System.Drawing.Point(305, 57);
            this.rb4.Name = "rb4";
            this.rb4.Size = new System.Drawing.Size(85, 36);
            this.rb4.TabIndex = 4;
            this.rb4.TabStop = true;
            this.rb4.Text = "鐮刀";
            this.rb4.UseVisualStyleBackColor = true;
            this.rb4.CheckedChanged += new System.EventHandler(this.rb4_CheckedChanged);
            // 
            // rb3
            // 
            this.rb3.AutoSize = true;
            this.rb3.Location = new System.Drawing.Point(213, 57);
            this.rb3.Name = "rb3";
            this.rb3.Size = new System.Drawing.Size(85, 36);
            this.rb3.TabIndex = 3;
            this.rb3.TabStop = true;
            this.rb3.Text = "肥料";
            this.rb3.UseVisualStyleBackColor = true;
            this.rb3.CheckedChanged += new System.EventHandler(this.rb3_CheckedChanged);
            // 
            // rb2
            // 
            this.rb2.AutoSize = true;
            this.rb2.Location = new System.Drawing.Point(122, 57);
            this.rb2.Name = "rb2";
            this.rb2.Size = new System.Drawing.Size(85, 36);
            this.rb2.TabIndex = 2;
            this.rb2.TabStop = true;
            this.rb2.Text = "種子";
            this.rb2.UseVisualStyleBackColor = true;
            this.rb2.CheckedChanged += new System.EventHandler(this.rb2_CheckedChanged);
            // 
            // rb1
            // 
            this.rb1.AutoSize = true;
            this.rb1.Location = new System.Drawing.Point(6, 57);
            this.rb1.Name = "rb1";
            this.rb1.Size = new System.Drawing.Size(110, 36);
            this.rb1.TabIndex = 1;
            this.rb1.TabStop = true;
            this.rb1.Text = "澆水壺";
            this.rb1.UseVisualStyleBackColor = true;
            this.rb1.CheckedChanged += new System.EventHandler(this.rb1_CheckedChanged);
            // 
            // B12
            // 
            this.B12.Location = new System.Drawing.Point(220, 324);
            this.B12.Name = "B12";
            this.B12.Size = new System.Drawing.Size(100, 100);
            this.B12.TabIndex = 12;
            this.B12.UseVisualStyleBackColor = true;
            this.B12.Click += new System.EventHandler(this.B12_Click);
            // 
            // B11
            // 
            this.B11.Location = new System.Drawing.Point(114, 324);
            this.B11.Name = "B11";
            this.B11.Size = new System.Drawing.Size(100, 100);
            this.B11.TabIndex = 11;
            this.B11.UseVisualStyleBackColor = true;
            this.B11.Click += new System.EventHandler(this.B11_Click);
            // 
            // B10
            // 
            this.B10.Location = new System.Drawing.Point(8, 324);
            this.B10.Name = "B10";
            this.B10.Size = new System.Drawing.Size(100, 100);
            this.B10.TabIndex = 10;
            this.B10.UseVisualStyleBackColor = true;
            this.B10.Click += new System.EventHandler(this.B10_Click);
            // 
            // B9
            // 
            this.B9.Location = new System.Drawing.Point(220, 218);
            this.B9.Name = "B9";
            this.B9.Size = new System.Drawing.Size(100, 100);
            this.B9.TabIndex = 9;
            this.B9.UseVisualStyleBackColor = true;
            this.B9.Click += new System.EventHandler(this.B9_Click);
            // 
            // B8
            // 
            this.B8.Location = new System.Drawing.Point(114, 218);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(100, 100);
            this.B8.TabIndex = 8;
            this.B8.UseVisualStyleBackColor = true;
            this.B8.Click += new System.EventHandler(this.B8_Click);
            // 
            // B7
            // 
            this.B7.Location = new System.Drawing.Point(8, 218);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(100, 100);
            this.B7.TabIndex = 7;
            this.B7.UseVisualStyleBackColor = true;
            this.B7.Click += new System.EventHandler(this.B7_Click);
            // 
            // B6
            // 
            this.B6.Location = new System.Drawing.Point(220, 112);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(100, 100);
            this.B6.TabIndex = 6;
            this.B6.UseVisualStyleBackColor = true;
            this.B6.Click += new System.EventHandler(this.B6_Click);
            // 
            // B5
            // 
            this.B5.Location = new System.Drawing.Point(114, 112);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(100, 100);
            this.B5.TabIndex = 5;
            this.B5.UseVisualStyleBackColor = true;
            this.B5.Click += new System.EventHandler(this.B5_Click);
            // 
            // B4
            // 
            this.B4.Location = new System.Drawing.Point(8, 112);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(100, 100);
            this.B4.TabIndex = 4;
            this.B4.UseVisualStyleBackColor = true;
            this.B4.Click += new System.EventHandler(this.B4_Click);
            // 
            // B3
            // 
            this.B3.Location = new System.Drawing.Point(220, 6);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(100, 100);
            this.B3.TabIndex = 3;
            this.B3.UseVisualStyleBackColor = true;
            this.B3.Click += new System.EventHandler(this.B3_Click);
            // 
            // B2
            // 
            this.B2.Location = new System.Drawing.Point(114, 6);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(100, 100);
            this.B2.TabIndex = 2;
            this.B2.UseVisualStyleBackColor = true;
            this.B2.Click += new System.EventHandler(this.B2_Click);
            // 
            // B1
            // 
            this.B1.Location = new System.Drawing.Point(8, 6);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(100, 100);
            this.B1.TabIndex = 1;
            this.B1.UseVisualStyleBackColor = true;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.money_label);
            this.tabPage2.Controls.Add(this.buy_sell);
            this.tabPage2.Controls.Add(this.fruit_label);
            this.tabPage2.Controls.Add(this.fert_label);
            this.tabPage2.Controls.Add(this.seed_label);
            this.tabPage2.Controls.Add(this.fruit);
            this.tabPage2.Controls.Add(this.fert);
            this.tabPage2.Controls.Add(this.seed);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(780, 429);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "商店";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // money_label
            // 
            this.money_label.AutoSize = true;
            this.money_label.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.money_label.Location = new System.Drawing.Point(340, 43);
            this.money_label.Name = "money_label";
            this.money_label.Size = new System.Drawing.Size(70, 32);
            this.money_label.TabIndex = 8;
            this.money_label.Text = "金錢:";
            // 
            // buy_sell
            // 
            this.buy_sell.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buy_sell.Location = new System.Drawing.Point(337, 305);
            this.buy_sell.Name = "buy_sell";
            this.buy_sell.Size = new System.Drawing.Size(87, 40);
            this.buy_sell.TabIndex = 7;
            this.buy_sell.Text = "買/賣";
            this.buy_sell.UseVisualStyleBackColor = true;
            this.buy_sell.Click += new System.EventHandler(this.buy_sell_Click);
            // 
            // fruit_label
            // 
            this.fruit_label.AutoSize = true;
            this.fruit_label.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fruit_label.Location = new System.Drawing.Point(539, 193);
            this.fruit_label.Name = "fruit_label";
            this.fruit_label.Size = new System.Drawing.Size(70, 32);
            this.fruit_label.TabIndex = 6;
            this.fruit_label.Text = "擁有:";
            // 
            // fert_label
            // 
            this.fert_label.AutoSize = true;
            this.fert_label.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fert_label.Location = new System.Drawing.Point(343, 193);
            this.fert_label.Name = "fert_label";
            this.fert_label.Size = new System.Drawing.Size(70, 32);
            this.fert_label.TabIndex = 5;
            this.fert_label.Text = "擁有:";
            // 
            // seed_label
            // 
            this.seed_label.AutoSize = true;
            this.seed_label.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.seed_label.Location = new System.Drawing.Point(133, 193);
            this.seed_label.Name = "seed_label";
            this.seed_label.Size = new System.Drawing.Size(70, 32);
            this.seed_label.TabIndex = 4;
            this.seed_label.Text = "擁有:";
            // 
            // fruit
            // 
            this.fruit.AutoSize = true;
            this.fruit.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fruit.Location = new System.Drawing.Point(539, 128);
            this.fruit.Name = "fruit";
            this.fruit.Size = new System.Drawing.Size(86, 36);
            this.fruit.TabIndex = 3;
            this.fruit.Text = "果實";
            this.fruit.UseVisualStyleBackColor = true;
            // 
            // fert
            // 
            this.fert.AutoSize = true;
            this.fert.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fert.Location = new System.Drawing.Point(343, 128);
            this.fert.Name = "fert";
            this.fert.Size = new System.Drawing.Size(86, 36);
            this.fert.TabIndex = 2;
            this.fert.Text = "肥料";
            this.fert.UseVisualStyleBackColor = true;
            // 
            // seed
            // 
            this.seed.AutoSize = true;
            this.seed.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.seed.Location = new System.Drawing.Point(133, 128);
            this.seed.Name = "seed";
            this.seed.Size = new System.Drawing.Size(86, 36);
            this.seed.TabIndex = 1;
            this.seed.Text = "種子";
            this.seed.UseVisualStyleBackColor = true;
            // 
            // pic
            // 
            this.pic.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.pic.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("pic.ImageStream")));
            this.pic.TransparentColor = System.Drawing.Color.Transparent;
            this.pic.Images.SetKeyName(0, "0.jpeg");
            this.pic.Images.SetKeyName(1, "1.jpg");
            this.pic.Images.SetKeyName(2, "2.jpg");
            this.pic.Images.SetKeyName(3, "3.jpg");
            this.pic.Images.SetKeyName(4, "4.jpg");
            this.pic.Images.SetKeyName(5, "5.jpg");
            this.pic.Images.SetKeyName(6, "6.jpg");
            this.pic.Images.SetKeyName(7, "7.jpg");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 463);
            this.Controls.Add(this.TabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tool.ResumeLayout(false);
            this.tool.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl TabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label money_label;
        private Button buy_sell;
        private Label fruit_label;
        private Label fert_label;
        private Label seed_label;
        private CheckBox fruit;
        private CheckBox fert;
        private CheckBox seed;
        private ImageList pic;
        private GroupBox tool;
        private Button B12;
        private Button B11;
        private Button B10;
        private Button B9;
        private Button B8;
        private Button B7;
        private Button B6;
        private Button B5;
        private Button B4;
        private Button B3;
        private Button B2;
        private Button B1;
        private RadioButton rb1;
        private RadioButton rb4;
        private RadioButton rb3;
        private RadioButton rb2;
    }
}