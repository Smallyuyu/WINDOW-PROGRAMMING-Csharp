namespace H24121133_practice_4_2
{
    public partial class Form1 : Form
    {
        private int seed_num = 5, fert_num = 5, fruit_num = 0, money_num = 100;
        private int cur_conditon = 1;
        private List<int> b_conditon = new List<int>();

        private void buy_sell_Click(object sender, EventArgs e)
        {
            if (fruit.Checked)
            {
                if (fruit_num >= 1)
                {
                    fruit_num--;
                    money_num += 40;
                }
            }
            if (seed.Checked)
            {
                if(money_num >= 10)
                {
                    seed_num++;
                    money_num -= 10;
                }
            }
            if (fert.Checked)
            {
                if(money_num >= 10)
                {
                    fert_num++;
                    money_num -= 10;
                }
            }
            show_();
        }

        private void tool_Enter(object sender, EventArgs e)
        {
        }

        private void show_()
        {
            seed_label.Text = "�֦�:" + seed_num;
            fert_label.Text = "�֦�:" + fert_num;
            fruit_label.Text = "�֦�" + fruit_num;
            money_label.Text = "����:" + money_num;
        }
        private bool check_(int n)
        {
            if (n <= 0) return false;
            return true;
        }
        private void errorMessage(int n)
        {
            if(n == 1) //�ؤl
            {
                MessageBox.Show("�ؤl�Χ��F", "ĵ�i",MessageBoxButtons.OK,MessageBoxIcon.Hand);
            }
            else if(n == 2) //�ή�
            {
                MessageBox.Show("�ήƥΧ��F", "ĵ�i", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }
        //�� = 0 �ؤl = 1 �g = 2 �I�M = 3
        private int do_(int con,int toolcon)
        {
            if(con == 0)// �g�a
            {
                if(toolcon == 1)//�ؤl
                {
                    if (check_(seed_num)) seed_num--;
                    else
                    {
                        errorMessage(1);
                        return con;
                    }
                    return 1;
                }
            }
            else if(con == 1) //�ؤl N�gN��
            {
                if (toolcon == 0) //��
                {
                    return 2;
                }
                else if (toolcon == 2) //�g
                {
                    if (check_(fert_num)) fert_num--;
                    else
                    {
                        errorMessage(2);
                        return con;
                    }
                    return 3;
                }
            }
            else if(con == 2) //�ؤl N�g
            {
                if(toolcon == 2)
                {
                    if (check_(fert_num)) fert_num--;
                    else
                    {
                        errorMessage(2);
                        return con;
                    }
                    return 4;
                }
            }
            else if(con == 3) //�ؤl N��
            {
                if(toolcon == 0)
                {
                    return 4;
                }
            }
            else if(con == 4) //�@�� N�gN��
            {
                if(toolcon == 0)
                {
                    return 5;
                }
                else if(toolcon == 2)
                {
                    if (check_(fert_num)) fert_num--;
                    else
                    {
                        errorMessage(2);
                        return con;
                    }
                    return 6;
                }
            }
            else if(con == 5) //�@�� N�g
            {
                if(toolcon == 2)
                {
                    if (check_(fert_num)) fert_num--;
                    else
                    {
                        errorMessage(2);
                        return con;
                    }
                    return 7;
                }
            }
            else if(con == 6) //�@�� N��
            {
                if(toolcon == 0)
                {
                    return 7;
                }
            }
            else if(con == 7) //�G��
            {
                if(toolcon == 3)
                {
                    fruit_num++;
                    return 0;
                }
            }
            return con;
        }
        private void B1_Click(object sender, EventArgs e)
        {
            b_conditon[1] = do_(b_conditon[1], cur_conditon);
            show_();
            show2_();
        }

        private void B2_Click(object sender, EventArgs e)
        {
            b_conditon[2] = do_(b_conditon[2], cur_conditon);
            show_();
            show2_();
        }

        private void B3_Click(object sender, EventArgs e)
        {
            b_conditon[3] = do_(b_conditon[3], cur_conditon);
            show_();
            show2_();
        }

        private void B4_Click(object sender, EventArgs e)
        {
            b_conditon[4] = do_(b_conditon[4], cur_conditon);
            show_();
            show2_();
        }

        private void B5_Click(object sender, EventArgs e)
        {
            b_conditon[5] = do_(b_conditon[5], cur_conditon);
            show_();
            show2_();
        }

        private void B6_Click(object sender, EventArgs e)
        {
            b_conditon[6] = do_(b_conditon[6], cur_conditon);
            show_();
            show2_();
        }

        private void B7_Click(object sender, EventArgs e)
        {
            b_conditon[7] = do_(b_conditon[7], cur_conditon);
            show_();
            show2_();
        }

        private void B8_Click(object sender, EventArgs e)
        {
            b_conditon[8] = do_(b_conditon[8], cur_conditon);
            show_();
            show2_();
        }

        private void B9_Click(object sender, EventArgs e)
        {
            b_conditon[9] = do_(b_conditon[9], cur_conditon);
            show_();
            show2_();
        }

        private void B10_Click(object sender, EventArgs e)
        {
            b_conditon[10] = do_(b_conditon[10], cur_conditon);
            show_();
            show2_();
        }

        private void B11_Click(object sender, EventArgs e)
        {
            b_conditon[11] = do_(b_conditon[11], cur_conditon);
            show_();
            show2_();
        }

        private void B12_Click(object sender, EventArgs e)
        {
            b_conditon[12] = do_(b_conditon[12], cur_conditon);
            show_();
            show2_();
        }

        private void rb1_CheckedChanged(object sender, EventArgs e)
        {
            if (rb1.Checked) cur_conditon = 0;
        }
        private void rb2_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2.Checked) cur_conditon = 1;
        }
        private void rb3_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3.Checked) cur_conditon = 2;
        }
        private void rb4_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4.Checked) cur_conditon = 3;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void show2_()
        {
            B1.Image = pic.Images[b_conditon[1]];
            B2.Image = pic.Images[b_conditon[2]];
            B3.Image = pic.Images[b_conditon[3]];
            B4.Image = pic.Images[b_conditon[4]];
            B5.Image = pic.Images[b_conditon[5]];
            B6.Image = pic.Images[b_conditon[6]];
            B7.Image = pic.Images[b_conditon[7]];
            B8.Image = pic.Images[b_conditon[8]];
            B9.Image = pic.Images[b_conditon[9]];
            B10.Image = pic.Images[b_conditon[10]];
            B11.Image = pic.Images[b_conditon[11]];
            B12.Image = pic.Images[b_conditon[12]];
        }

        public Form1()
        {
            InitializeComponent();
            for (int i = 0; i <= 12; i++)
            {
                b_conditon.Add(0);
            }
            /*tool.Controls.Add(rb1);
            tool.Controls.Add(rb2);
            tool.Controls.Add(rb3);
            tool.Controls.Add(rb4);*/
            show_();
            show2_();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
    }
}