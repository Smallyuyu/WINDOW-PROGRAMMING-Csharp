using System.Security.Cryptography.Xml;

namespace H24121133_practice_4_1
{
    public partial class Form1 : Form
    {
        private List<int> ans = new List<int>();
        private List<int> cnt = new List<int>();
        private int ansS = 0;
        public Form1()
        {
            InitializeComponent();
            Random rnd = new Random();
            rnd.Next();
            for(int i = 0; i < 4; i++)
            {
                cnt.Add(0);
                ans.Add(rnd.Next(0, 10));
                ansS = ansS + ans[i] * (1 << i);
            }
            button1.Image = imageList1.Images[cnt[0]];
            button2.Image = imageList1.Images[cnt[1]];
            button3.Image = imageList1.Images[cnt[2]];
            button4.Image = imageList1.Images[cnt[3]];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cnt[0]++;
            cnt[0] %= 10;
            button1.Image = imageList1.Images[cnt[0]];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cnt[1]++;
            cnt[1] %= 10;
            button2.Image = imageList1.Images[cnt[1]];
        }
        private void button3_Click(object sender, EventArgs e)
        {
            cnt[2]++;
            cnt[2] %= 10;
            button3.Image = imageList1.Images[cnt[2]];
        }
        private void button4_Click(object sender, EventArgs e)
        {
            cnt[3]++;
            cnt[3] %= 10;
            button4.Image = imageList1.Images[cnt[3]];
        }
        private void button5_Click(object sender, EventArgs e)
        {
            int cur = 0;
            for(int i = 0; i < 4; i++)
            {
                if (ans[i] == cnt[i]) cur++;
            }
            DialogResult result;
            if(cur == 4)
            {
                MessageBox.Show("���ꦨ�\","���\",MessageBoxButtons.OK,MessageBoxIcon.Question);
            }
            else
            {
                result = MessageBox.Show("�q��" + cur + "�Ӧ�m","����",MessageBoxButtons.RetryCancel,MessageBoxIcon.Hand);
                if(result == DialogResult.Cancel)
                {
                    char[] c = new char[4];
                    string s = "";
                    for (int i = 0; i < 4; i++){
                        c[i] = Convert.ToChar(ans[i] + 48);
                    }
                    s = new string(c);
                    MessageBox.Show("���׬O" + s);
                }
            }
        }
    }
}