﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Local_Variable
{
    class Program
    {
        static void Main(string[] args)
        {
                      int n = 20;
                     for (int n = 0; n < 6; n++)
                          {
                              Console.WriteLine(" n = {0} ", n);
                          }
                      Console.WriteLine(" n1 = {0} ", n);
                      Console.Read();

        }
    }
}
