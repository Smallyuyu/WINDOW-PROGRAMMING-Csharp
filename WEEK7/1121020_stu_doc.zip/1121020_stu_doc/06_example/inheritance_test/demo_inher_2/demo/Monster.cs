﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo
{
    class Monster : Creature
    {



        public void Attack(Villager vi)
        {
            vi.Injured(50);
        }


    }
}
