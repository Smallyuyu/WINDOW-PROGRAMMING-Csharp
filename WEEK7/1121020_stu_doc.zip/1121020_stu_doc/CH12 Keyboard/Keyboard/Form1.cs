﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Keyboard
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); 
            label2.Visible = false;
        }

        private void Press_key(object sender, MouseEventArgs e)
        {
        }

        private void Press_key(object sender, KeyEventArgs e)
        {
            label2.Visible = true;

            label2.Text = String.Format("按了 {0} 鍵，鍵碼：{1}", e.KeyCode, e.KeyValue);
           
            switch (e.KeyData)
            {
                case Keys.Up: 
                    label2.Top -= label2.Height / 2; 
                    break;
                case Keys.Down: 
                    label2.Top += label2.Height / 2; 
                    break;
                case Keys.Left: 
                    label2.Left -= label2.Width / 2; 
                    break;
                case Keys.Right: 
                    label2.Left += label2.Width / 2; 
                    break;
            }
        }

        private void Mouse_D(object sender, MouseEventArgs e)
        {
            label1.Visible = true;
            string s = "";
            switch (e.Button)
            {
                case MouseButtons.Left: 
                    s = "左鍵"; 
                    break;
                case MouseButtons.Middle: 
                    s = "中間鍵"; 
                    break;
                case MouseButtons.Right: 
                    s = "右鍵"; 
                    break;
            }
            label1.Text = String.Format("按了{0}於 X：{1}, Y：{2}", s, e.X, e.Y);
        }

    }
}
