using System.Security.Cryptography.Xml;

namespace H24121133_practice_5_1
{
    public partial class Form1 : Form
    {
        int cur_time = 5;
        int Exit_Flag = 0;
        List<int> player_press = new List<int>();
        List<Button> button_array = new List<Button>();
        List<int> ans = new List<int>();
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
        }
        private void Form1_load(object sender, EventArgs e) {
            for (int i = 0; i <= 9; i++)
            {
                button_array.Add((Button)this.Controls[("button" + i).ToString()]);
                button_array[i].Text = (i).ToString();
            }
            for (int i = 65; i <= 90; i++)
            {
                button_array.Add((Button)this.Controls[("button" + (i - 65 + 10)).ToString()]);
                button_array[i - 65 + 10].Text = ((char)i).ToString();
            }
            button.Visible = true;
            label.Visible = false;
            label1.Visible = false;
            foreach (Button button in button_array)
            {
                button.Visible = false;
            }
        }
        private void timer1_Tick(object sender, EventArgs e) {
            cur_time--;
            label1.Text = (cur_time).ToString();
            if (cur_time == 0) {
                timer1.Stop();
                Exit_Flag++;
            }
        }
        private void start_game()
        {
            for(int i = 0; i < 36; i++)
            {
                button_array[i].BackColor = Color.White;
            }
            //PREPARE
            label.Text = "�ǳƶ��q";
            cur_time = 5;
            timer1.Interval = 1000;
            Random rnd = new Random();
            for (int i = 0; i < 3; i++)
            {
                int rn = rnd.Next(35);
                if (ans.Contains(rn))
                {
                    i--;
                    continue;
                }
                ans.Add(rn);
            }
            foreach(int x in ans){
                button_array[x].BackColor = Color.LightGreen;
            }
            Exit_Flag = 0;
            timer1.Start();
            while (Exit_Flag == 0)
            {
                Application.DoEvents();
            }
            //PLAYER
            label.Text = "���a���q";
            cur_time = 5;
            timer1.Interval = 1000;
            foreach (int x in ans)
            {
                button_array[x].BackColor = Color.White;
            }
            timer1.Start();
            while (Exit_Flag == 1)
            {
                Application.DoEvents();
            }
            int cnt = 0;
            foreach(int x in player_press)
            {
                if (ans.Contains(x))
                {
                    cnt++;
                    button_array[x].BackColor = Color.LightGreen;
                }
                else button_array[x].BackColor = Color.Red;
            }
            foreach(int x in ans)
            {
                if (!player_press.Contains(x))
                {
                    button_array[x].BackColor = Color.Red;
                }
            }
            if (cnt == 3)
            {
                var result = MessageBox.Show("You Win!", " ");
            }
            else
            {
                var result = MessageBox.Show("You Lose!\nTry Again!", " ");
            }
            ans = new List<int>();
            player_press = new List<int>();
            Exit_Flag = 0;
            start_game();
        }
        private void button_Click(object sender, EventArgs e)
        {
            button.Visible = false;
            label.Visible = true;
            label1.Visible = true;
            foreach (Button button in button_array)
            {
                button.Visible = true;
            }
            start_game();
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (Exit_Flag == 1)
            {
                int value = e.KeyValue;
                if (value >= 65 && value <= 90)
                {
                    if (!player_press.Contains(e.KeyValue - 65 + 10))
                    {
                        player_press.Add(e.KeyValue - 65 + 10);
                        button_array[e.KeyValue - 65 + 10].BackColor = Color.LightBlue;
                    }
                }
                else if (value >= 48 && value <= 57)
                {
                    if (!player_press.Contains(e.KeyValue - 48))
                    {
                        player_press.Add(e.KeyValue - 48);
                        button_array[e.KeyValue - 48].BackColor = Color.LightBlue;
                    }
                }
                else if(value >= 97 && value <= 122)
                {
                    if (!player_press.Contains(e.KeyValue - 97 + 10))
                    {
                        player_press.Add(e.KeyValue - 97 + 10);
                        button_array[e.KeyValue - 97 + 10].BackColor = Color.LightBlue;
                    }
                }
            }
        }

        private void label_Click(object sender, EventArgs e)
        {

        }
    }
}