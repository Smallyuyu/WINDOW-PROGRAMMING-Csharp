using System.Security.Cryptography.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using System.Windows.Forms;
using System.Runtime.CompilerServices;

namespace H24121133_practice_5_2
{
    public partial class Form1 : Form
    {
        class Servant
        {
            public string character;
            public int hp;
            public int charge;
            public int atk;
            public int speed;
            public int cc;
            public virtual void Skill(){}
            public virtual void Big_Skill() { }
            public void Got_Attack(int damage) {hp -= damage;}
            public Servant(string character_,int hp_,int charge_,int atk_,int speed_)
            {
                character = character_; hp = hp_; charge = charge_; atk = atk_; speed = speed_; cc = 2;
            }
        };
        class Berserker: Servant
        {
            public Berserker(string character_, int hp_, int charge_, int atk_, int speed_) : base(character_, hp_, charge_, atk_, speed_) { }
            public void Skill()
            {
                cc = 2;
                atk = atk * 2;
                hp = hp / 2;
            }
            public void Skill_reverse()
            {
                cc = 0;
                atk = atk / 2;
            }
            public void Big_Skill()
            {
                atk += 50;
            }
            public void Got_Attack(int damage) { hp -= damage; }
        }
        class Saber : Servant
        {
            public Saber(string character_, int hp_, int charge_, int atk_, int speed_) : base(character_, hp_, charge_, atk_, speed_) { }
            public void Skill()
            {
                cc = 2;
                atk += 50;
            }
            public void Skill_reverse()
            {
                cc = 0;
                atk -= 50;
            }
            public void Big_Skill()
            {
                atk += 25;
                hp += 5;
            }
        }
        class Caster : Servant
        {
            public Caster(string character_, int hp_, int charge_, int atk_, int speed_) : base(character_, hp_, charge_, atk_, speed_) { }
            public void Skill()
            {
                cc = 2;
                hp += hp / 2;
            }
            public void Skill_reverse()
            {
                cc = 0;
            }
        }
        class Beast : Servant
        {
            public Beast(string character_, int hp_, int charge_, int atk_, int speed_) : base(character_, hp_, charge_, atk_, speed_) { }
            public void Skill()
            {
                cc = 4;
                atk += 2;
            }
        }
        List<bool> ch_flag = new List<bool>(){false,false,false};
        int cur_time = 10,now_turn_player;
        bool stage3_flag = false,end_flag = false,fight_flag = true;
        List<int> turn_list = new List<int>();
        List<bool> life = new List<bool>{ true, true, true, true };
        bool small_skill, big_skill;
        Saber Saber_ = new Saber("Saber", 100, 0, 3, 1);
        Caster Caster_ = new Caster("Caster", 100, 0, 2, 2);
        Berserker Berserker_ = new Berserker("Berserker", 100, 0, 4, 4);
        Beast Beast_ = new Beast("Beast", 500, 0, 2, 3);
        public Form1()
        {
            InitializeComponent();
            for (int i = 0; i < 3; i++) ch_flag[i] = false;
            stage1();
        }
        private void close_all()
        {
            turntxt.Visible = false;
            start_button.Visible = false;
            label.Visible = false;
            timer_.Visible = false;
            Berserker_Button.Visible = false;
            Saber_Button.Visible = false;
            Caster_Button.Visible = false;
            player1.Visible = false;
            player2.Visible = false;
        }
        private void stage2_show()
        {
            label.Text = "�ǳƶ��q";
            label.Location = new Point(327, 28); label.Size = new Size(123, 35); label.Visible = true;
            timer_.Location = new Point(367, 79); timer_.Size = new Size(41, 30); timer_.Visible = true;
            Berserker_Button.Location = new Point(180, 186); Berserker_Button.Size = new Size(100, 41); Berserker_Button.Visible = true;
            Saber_Button.Location = new Point(340, 186); Saber_Button.Size = new Size(100, 41); Saber_Button.Visible = true;
            Caster_Button.Location = new Point(500, 186); Caster_Button.Size = new Size(100, 41); Caster_Button.Visible = true;
        }
        private void stage3_show()
        {
            turntxt.Visible = true;
            turntxt.Text = " ";
            label.Text = "  �� ��";
            label.Visible = true;
            timer_.Visible = true;
            end_flag = false;
            Berserker_Button.Text = "����";
            Saber_Button.Text = "�ޯ�";
            Caster_Button.Text = "�_��";
            Berserker_Button.Visible = true;
            Saber_Button.Visible = true;
            Caster_Button.Visible = true;
            player1.Location = new Point(30, 144); player1.Visible = true;
            player2.Location = new Point(660, 144); player2.Visible = true;
        }
        private void time_set()
        {
            timer1.Interval = 1000;
            cur_time = 10;
            timer1.Start();
        }
        private int Rnd(int left,int right)
        {
            Random rnd = new Random();
            return rnd.Next(left,right + 1);
        }
        private void stage1()
        {
            close_all();
            start_button.Location = new Point(296, 310);start_button.Size = new Size(200, 44);start_button.Visible = true;
        }
        private void stage2()
        {
            close_all();
            stage2_show();
            time_set();
            while(!stage3_flag) {
                Application.DoEvents();
            }
            pre_stage3();
            stage3();
        }
        private void pre_stage3()
        {
            int cnt = 0;
            for (int i = 0; i < 3; i++)
            {
                if (ch_flag[i] == true) cnt++;
                Berserker_Button.BackColor = Color.White;
                Saber_Button.BackColor = Color.White;
                Caster_Button.BackColor = Color.White;
            }
            if (cnt != 2)
            {
                for (int i = 0; i < 3; i++)
                {
                    if (!ch_flag[i])
                    {
                        ch_flag[i] = true;
                        cnt++;
                    }
                    if (cnt == 2) break;
                }
            }
            for (int i = 0; i < 3; i++)
            {
                if (ch_flag[i] == true)
                {
                    turn_list.Add(i);
                }
            }
            turn_list.Add(3);
            for (int i = 0; i < 3; i++)
            {
                for (int j = i + 1; j < 3; j++)
                {
                    if (change_to_speed(turn_list[i]) < change_to_speed(turn_list[j]))
                    {
                        int tmp = turn_list[i];
                        turn_list[i] = turn_list[j];
                        turn_list[j] = tmp;
                    }
                }
            }
        }
        private void update_conditon()
        {
            if(now_turn_player == 0)
            {
                player1.Text = "Berserker\nHP: " + Berserker_.hp + "\nCharge: " + Berserker_.charge + "\nAttack:" + Berserker_.atk;
            }
            else if(now_turn_player == 1)
            {
                player1.Text = "Saber\nHP: " + Saber_.hp + "\nCharge: " + Saber_.charge + "\nAttack:" + Saber_.atk;
            }
            else if(now_turn_player == 2)
            {
                player1.Text = "Caster\nHP: " + Caster_.hp + "\nCharge: " + Caster_.charge + "\nAttack:" + Caster_.atk;
            }
            player2.Text = "Beast\nHP: " + Beast_.hp + "\nCharge: " + Beast_.charge + "\nAttack:" + Beast_.atk;
        }
        private int change_to_speed(int x)
        {
            if(x == 0) //BerSerker
            {
                return 4;
            }
            else if(x == 1) //Saber
            {
                return 1;
            }
            else if(x == 2) //Caster
            {
                return 2;
            }
            else if(x == 3) //Beast
            {
                return 3;
            }
            return 0;
        }
        private void turn_show()
        {
            if(now_turn_player == 0)
            {
                turntxt.Text = "Berserker turn";
            }
            else if(now_turn_player == 1)
            {
                turntxt.Text = "Saber turn";
            }
            else if(now_turn_player == 2)
            {
                turntxt.Text = "Caster turn";
            }
        }
        private void stage3()
        {
            Beast_.cc = 4;
            close_all();
            stage3_show();
            int turn = 0;
            while (true)
            {
                timer_.Text = (turn + 1).ToString();
                now_turn_player = turn_list[(turn) % 3];
                if (!life[turn % 3])
                {
                    turn++;
                    continue;
                }
                update_conditon();
                turn_show();
                if (now_turn_player == 0) Berserker_.cc--;
                else if (now_turn_player == 1) Saber_.cc--;
                else if (now_turn_player == 2) Caster_.cc--;
                else Beast_.cc--;
                fight_flag = false;
                small_skill = false;
                big_skill = false;
                if (now_turn_player == 3)
                {
                    Beast_turn();
                }
                else
                {
                    while (!fight_flag)
                    {
                        Application.DoEvents();
                    }
                }
                if(Beast_.hp <= 0)
                {
                    MessageBox.Show("You Win!\n�q���ɶ�:" + (turn + 1));
                    break;
                }
                check_life();
                if (check_end())
                {
                    MessageBox.Show("You Lose\n�q���ɶ�:" + (turn + 1));
                    break;
                }
                turn++;
            }
        }
        private void check_life()
        {
            foreach(int x in turn_list)
            {
                if (x == 0)
                {
                    if(Berserker_.hp <= 0 && life[x] == true)
                    {
                        MessageBox.Show("Berserker�ˤU�F!");
                        life[x] = false;
                    }
                }
                else if(x == 1)
                {
                    if(Saber_.hp <= 0 && life[x] == true)
                    {
                        MessageBox.Show("Saber�ˤU�F!");
                        life[x] = false;
                    }
                }
                else if(x == 2)
                {
                    if(Caster_.hp <= 0 && life[x] == true)
                    {
                        MessageBox.Show("Caster�ˤU�F!");
                        life[x] = false;
                    }
                }
            }
        }
        private void Beast_turn()
        {
            if (Beast_.cc <= 0)
            {
                Beast_.Skill();
                MessageBox.Show("Beast�ϥΤF�ޯ�\n���eATK:" + Beast_.atk);
            }
            if (Beast_.charge < 100)
            {
                if (Rnd(0, 1) == 1)
                {
                    Berserker_.Got_Attack(Beast_.atk * 2);
                    Saber_.Got_Attack(Beast_.atk * 2);
                    Caster_.Got_Attack(Beast_.atk * 2);
                    MessageBox.Show("Beast����鶤���y��" + (Beast_.atk * 2) + "�I�ˮ`!");
                }
                else
                {
                    Berserker_.Got_Attack(Beast_.atk);
                    Saber_.Got_Attack(Beast_.atk);
                    Caster_.Got_Attack(Beast_.atk);
                    MessageBox.Show("Beast����鶤���y��" + Beast_.atk + "�I�����ˮ`!");
                }
            }
            else
            {
                Beast_.charge -= 100;
                Berserker_.Got_Attack(Beast_.atk * 2);
                Saber_.Got_Attack(Beast_.atk * 2);
                Caster_.Got_Attack(Beast_.atk * 2);
                MessageBox.Show("Beast�ϥΤF�_��\n����鶤���y��" + (Beast_.atk * 2) + "�I�ˮ`!");
            }
            Beast_.charge += 20;
        }
        private bool check_end()
        {
            int cnt = 0;
            foreach(int x in turn_list)
            {
                if (!life[x]) cnt++;
            }
            if (cnt == 2) return true;
            return false;
        }
        private void start_button_Click(object sender, EventArgs e)
        {
            stage2();
        }
        private void check_ch_num(int n)
        {
            int cnt = 0;
            for(int i = 0; i < 3; i++)
            {
                if (ch_flag[i])
                {
                    cnt++;
                }
            }
            if(cnt == 2)
            {
                MessageBox.Show("�u�����Servant!","");
            }
            else
            {
                if (n == 0) Berserker_Button.BackColor = Color.LightGreen;
                else if(n == 1) Saber_Button.BackColor = Color.LightGreen;
                else Caster_Button.BackColor = Color.LightGreen;
                ch_flag[n] = true;
            }
        }
        private void Berserker_Button_Click(object sender, EventArgs e)
        {
            if (stage3_flag)
            {
                if (Rnd(0, 1) == 1) //����
                {
                    int d = 0;
                    if (now_turn_player == 0)
                    {
                        Beast_.Got_Attack(Berserker_.atk * 2);
                        Berserker_.charge += Rnd(20, 25);
                        d = Berserker_.atk * 2;
                    }
                    else if (now_turn_player == 1)
                    {
                        Beast_.Got_Attack(Saber_.atk * 2);
                        Saber_.charge += Rnd(20, 25);
                        d = Saber_.atk * 2;
                    }
                    else if (now_turn_player == 2)
                    {
                        Beast_.Got_Attack(Caster_.atk * 2);
                        Caster_.charge += Rnd(20, 25);
                        d = Caster_.atk * 2;
                    }
                    MessageBox.Show("��Beast�y���F" + d + "�I�����ˮ`", "");
                }
                else
                {
                    int d = 0;
                    if (now_turn_player == 0)
                    {
                        Beast_.Got_Attack(Berserker_.atk * 2);
                        Berserker_.charge += 30;
                        d = Berserker_.atk * 2;
                    }
                    else if (now_turn_player == 1)
                    {
                        Beast_.Got_Attack(Saber_.atk * 2);
                        Saber_.charge += 30;
                        d = Saber_.atk * 2;
                    }
                    else if (now_turn_player == 2)
                    {
                        Beast_.Got_Attack(Caster_.atk * 2);
                        Caster_.charge += 30;
                        d = Caster_.atk * 2;
                    }
                    MessageBox.Show("��Beast�y���F" + d + "�I�����ˮ`","");
                }
                fight_flag = true;
            }
            else
            {
                if (ch_flag[0])
                {
                    Berserker_Button.BackColor = Color.White;
                    ch_flag[0] = false;
                }
                else
                {
                    check_ch_num(0);
                }
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Saber_Button_Click(object sender, EventArgs e)
        {
            if(small_skill == true)
            {
                MessageBox.Show("�ޯ�N�o��(�Ѿl�^�X:3)");
            }
            else if (stage3_flag)
            {
                if (now_turn_player == 0)
                {
                    if(Berserker_.cc <= 0)
                    {
                        Berserker_.Skill();
                        MessageBox.Show("Berserker�ϥΤF�ޯ�");
                        small_skill = true;
                        update_conditon();
                    }
                    else
                    {
                        MessageBox.Show("�ޯ�N�o��(�Ѿl�^�X:" + Berserker_.cc + ")");
                    }
                }
                else if (now_turn_player == 1)
                {
                    if (Saber_.cc <= 0)
                    {
                        Saber_.Skill();
                        MessageBox.Show("Saber�ϥΤF�ޯ�");
                        small_skill = true;
                        update_conditon();
                    }
                    else
                    {
                        MessageBox.Show("�ޯ�N�o��(�Ѿl�^�X:" + Saber_.cc + ")");
                    }
                }
                else if (now_turn_player == 2)
                {
                    if (Caster_.cc <= 0)
                    {
                        Caster_.Skill();
                        MessageBox.Show("Caster�ϥΤF�ޯ�");
                        small_skill = true;
                        update_conditon();
                    }
                    else
                    {
                        MessageBox.Show("�ޯ�N�o��(�Ѿl�^�X:" + Caster_.cc + ")");
                    }
                }
            }
            else
            {
                if (ch_flag[1])
                {
                    Saber_Button.BackColor = Color.White;
                    ch_flag[1] = false;
                }
                else
                {
                    check_ch_num(1);
                }
            }
        }

        private void Caster_Button_Click(object sender, EventArgs e)
        {
            if (stage3_flag)
            {
                if(now_turn_player == 0)
                {
                    if (Berserker_.charge >= 100)
                    {
                        Beast_.Got_Attack(Berserker_.atk + 50);
                        Berserker_.charge -= 100;
                        MessageBox.Show("Berserker�ϥΤF�_��:\n��Beast�y��" + (Berserker_.atk + 50) + "�I�ˮ`");
                        update_conditon();
                        if (Beast_.hp <= 0) fight_flag = true;
                    }
                    else MessageBox.Show("�R�ण��,�L�k�I���_��!");
                }
                else if(now_turn_player == 1)
                {
                    if(Saber_.charge >= 100)
                    {
                        Saber_.charge -= 100;
                        Saber_.hp += 5;
                        Beast_.Got_Attack(Saber_.atk + 25);
                        MessageBox.Show("Saber�ϥΤF�_��:\n��Beast�y��" + (Saber_.atk + 25) + "�I�ˮ`�æ^�_5�I��q");
                        update_conditon();
                        if (Beast_.hp <= 0) fight_flag = true;
                    }
                    else MessageBox.Show("�R�ण��,�L�k�I���_��!");
                }
                else if(now_turn_player == 2)
                {
                    if(Caster_.charge >= 100)
                    {
                        Caster_.charge -= 100;
                        Berserker_.atk++; Berserker_.hp += 10;
                        Saber_.atk++; Saber_.hp += 10;
                        Caster_.atk++; Caster_.hp += 10;
                        MessageBox.Show("Caster�ϥΤF�_��:\n���鶤�ͥ[1�I�����B�^�_10�I��q");
                        update_conditon();
                    }
                    else MessageBox.Show("�R�ण��,�L�k�I���_��!");
                }
            }
            else
            {
                if (ch_flag[2])
                {
                    Caster_Button.BackColor = Color.White;
                    ch_flag[2] = false;
                }
                else
                {
                    check_ch_num(2);
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            cur_time--;
            timer_.Text = cur_time.ToString();
            if (cur_time == 0)
            {
                stage3_flag = true;
                timer1.Stop();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}