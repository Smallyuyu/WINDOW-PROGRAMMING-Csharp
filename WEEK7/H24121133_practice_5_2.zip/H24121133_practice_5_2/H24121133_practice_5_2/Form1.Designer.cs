﻿namespace H24121133_practice_5_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label = new System.Windows.Forms.Label();
            this.start_button = new System.Windows.Forms.Button();
            this.timer_ = new System.Windows.Forms.Label();
            this.Berserker_Button = new System.Windows.Forms.Button();
            this.Saber_Button = new System.Windows.Forms.Button();
            this.Caster_Button = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.player1 = new System.Windows.Forms.Label();
            this.player2 = new System.Windows.Forms.Label();
            this.turntxt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft JhengHei UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label.Location = new System.Drawing.Point(327, 28);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(123, 35);
            this.label.TabIndex = 1;
            this.label.Text = "準備階段";
            this.label.Visible = false;
            // 
            // start_button
            // 
            this.start_button.Font = new System.Drawing.Font("Microsoft JhengHei UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.start_button.Location = new System.Drawing.Point(21, 202);
            this.start_button.Name = "start_button";
            this.start_button.Size = new System.Drawing.Size(10, 13);
            this.start_button.TabIndex = 0;
            this.start_button.Text = "開始遊戲";
            this.start_button.UseVisualStyleBackColor = true;
            this.start_button.Click += new System.EventHandler(this.start_button_Click);
            // 
            // timer_
            // 
            this.timer_.AutoSize = true;
            this.timer_.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.timer_.Location = new System.Drawing.Point(367, 79);
            this.timer_.Name = "timer_";
            this.timer_.Size = new System.Drawing.Size(41, 30);
            this.timer_.TabIndex = 2;
            this.timer_.Text = "10";
            // 
            // Berserker_Button
            // 
            this.Berserker_Button.Location = new System.Drawing.Point(21, 241);
            this.Berserker_Button.Name = "Berserker_Button";
            this.Berserker_Button.Size = new System.Drawing.Size(14, 17);
            this.Berserker_Button.TabIndex = 3;
            this.Berserker_Button.Text = "Berserker";
            this.Berserker_Button.UseVisualStyleBackColor = true;
            this.Berserker_Button.Click += new System.EventHandler(this.Berserker_Button_Click);
            // 
            // Saber_Button
            // 
            this.Saber_Button.Location = new System.Drawing.Point(21, 301);
            this.Saber_Button.Name = "Saber_Button";
            this.Saber_Button.Size = new System.Drawing.Size(14, 18);
            this.Saber_Button.TabIndex = 4;
            this.Saber_Button.Text = "Saber";
            this.Saber_Button.UseVisualStyleBackColor = true;
            this.Saber_Button.Click += new System.EventHandler(this.Saber_Button_Click);
            // 
            // Caster_Button
            // 
            this.Caster_Button.Location = new System.Drawing.Point(25, 353);
            this.Caster_Button.Name = "Caster_Button";
            this.Caster_Button.Size = new System.Drawing.Size(10, 12);
            this.Caster_Button.TabIndex = 5;
            this.Caster_Button.Text = "Caster";
            this.Caster_Button.UseVisualStyleBackColor = true;
            this.Caster_Button.Click += new System.EventHandler(this.Caster_Button_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // player1
            // 
            this.player1.AutoSize = true;
            this.player1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player1.Location = new System.Drawing.Point(70, 144);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(85, 30);
            this.player1.TabIndex = 6;
            this.player1.Text = "Caster";
            // 
            // player2
            // 
            this.player2.AutoSize = true;
            this.player2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player2.Location = new System.Drawing.Point(660, 144);
            this.player2.Name = "player2";
            this.player2.Size = new System.Drawing.Size(75, 30);
            this.player2.TabIndex = 7;
            this.player2.Text = "Beast";
            // 
            // turntxt
            // 
            this.turntxt.AutoSize = true;
            this.turntxt.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.turntxt.Location = new System.Drawing.Point(351, 353);
            this.turntxt.Name = "turntxt";
            this.turntxt.Size = new System.Drawing.Size(81, 30);
            this.turntxt.TabIndex = 8;
            this.turntxt.Text = "label1";
            this.turntxt.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.turntxt);
            this.Controls.Add(this.player2);
            this.Controls.Add(this.player1);
            this.Controls.Add(this.label);
            this.Controls.Add(this.Caster_Button);
            this.Controls.Add(this.Saber_Button);
            this.Controls.Add(this.Berserker_Button);
            this.Controls.Add(this.timer_);
            this.Controls.Add(this.start_button);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label;
        private Button start_button;
        private Label timer_;
        private Button Berserker_Button;
        private Button Saber_Button;
        private Button Caster_Button;
        private System.Windows.Forms.Timer timer1;
        private Label player1;
        private Label player2;
        private Label turntxt;
    }
}